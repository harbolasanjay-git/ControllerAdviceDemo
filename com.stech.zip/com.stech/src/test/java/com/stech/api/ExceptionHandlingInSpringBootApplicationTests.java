package com.stech.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ExceptionHandlingInSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
